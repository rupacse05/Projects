
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Vector;
import java.util.*;
import java.io.*; 

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer One
 */
public class termdoc {
    public static void main(String[]args) throws FileNotFoundException, UnsupportedEncodingException{
        File file2 = new File("D:\\logs\\termdoc.txt");
        PrintWriter tdr = new PrintWriter(file2, "UTF-8");
        Map<String, Integer> m = new HashMap<>();
        Map<Integer,Map>m1=new HashMap<>();
        String wrd;
        int unqwrd=0;
        
        for(int i=1;i<=1400;i++){
            Scanner tdsc=new Scanner(new File("D:\\logs\\AfterStem"+i+".txt"));
            while(tdsc.hasNext()){
              Integer docid=i;
              wrd=tdsc.next();
              Integer freq=m.get(wrd);
              m.put(wrd, (freq == null) ? 1 : freq + 1);
              m1.put(docid,m);
       
           }
        tdr.println(m1);
        m.clear();
        m1.clear();
        tdsc.close();
        
    }
        //System.out.println(m.size() + " distinct words");
        tdr.close();
       
        
}
    
}
