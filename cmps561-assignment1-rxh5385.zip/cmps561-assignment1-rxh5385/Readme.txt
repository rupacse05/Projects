Rashida Hasan
CLID : rxh5385

Step 1 : Parsing the file into individual documents and words
Step 2: Removing the stop words from those individual documents

Project Name : StopWordsRemove
1. open the project in Netbeans
2. Create a folder name "logs" in D drive
3. Put the "cran.all.1400" file into the "logs" folder
4. The number of documents and the documents after  removing stopwords will be stored in the "logs" folder ( when you run the code)

Step 3: Stem the words using porter stemmer algorithm

Project Name: Stemmer

1. It will produce 1400 txt files named "After Stem" in logs folder (after running the project)
2. All of the docs are now cleaned ( remove stop words as well as stem the words in the docs)

Step 4 : Term document Matrix
Step 5: Inverted Index
Step 6 : Store the information into database as a triple (t,d,w)