import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class Stp_Wrd_Rmv {

    /**
     * @param args
     * @throws IOException 
     */
   public static void main(String[] args) throws IOException {
    String inputFile="D:\\logs\\cran.all.1400"; 
    BufferedReader br = new BufferedReader(new FileReader(new File(inputFile)));
    BufferedReader brstop = new BufferedReader(new FileReader("stop.txt"));
    String line=null;
    String words;
    int count=1;
    int noOfDoc=0, noOfWords=0;
    Set<String> stopWords = new LinkedHashSet<>();
    Set<String> st2 = new LinkedHashSet<>();
        while( (words = brstop.readLine()) != null) {
            stopWords.add(words.trim());
            //System.out.println(stopWords);
            }
         //System.out.println(stopWords.size());
    try {
        PrintWriter writer = null;
        while((line = br.readLine()) != null){
            if(line.startsWith(".I")){
                if(writer != null) writer.close();
                File file = new File("D:\\logs\\DOC_ID_"+count+".txt");
                noOfDoc++;
                writer = new PrintWriter(file, "UTF-8");
                count++;
            }
            if(writer != null){
                //writer.println(line);
               writer.println(line);
                //System.out.println(line);
            }
            
        }
        System.out.println("The number of documents in the collection :" +noOfDoc);
        if(writer != null){
            writer.close();
        }
    } catch (Exception ex) {
         ex.printStackTrace();
    } finally {
        br.close();
    }
    PrintWriter wr;
    for(int i=1;i<=1400;i++){
        File file = new File("D:\\logs\\after-stopword-remove"+i+".txt");
        wr = new PrintWriter(file, "UTF-8");
       Scanner sc=new Scanner(new File("D:\\logs\\DOC_ID_"+i+".txt"));
       while(sc.hasNext()){
              st2.add(sc.next());
              
          }
        //System.out.println(st2.size());
        noOfWords=noOfWords+st2.size();
        st2.removeAll(stopWords);
        //System.out.println(st2);
        wr.println(st2);
        wr.close();
        st2.clear();
        brstop.close();
        sc.close();

      }
    System.out.println("The number of words in the collection:" +noOfWords);
    
    
   }
   
   
       }

