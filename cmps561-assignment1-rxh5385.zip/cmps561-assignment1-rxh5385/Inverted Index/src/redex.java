import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
  * Stemmer, implementing the Porter Stemming Algorithm
  *
  * The Stemmer class transforms a word into its root form.  The input
  * word can be provided a character at time (by calling add()), or at once
  * by calling one of the various stem(something) methods.
  */


  class redex{
      public static void main(String[]args) throws FileNotFoundException{
    Map<String, Set<Doc>> wordDocMap = new HashMap<>();

    for(int i=1;i<=1400;i++){
        Scanner tdsc = new Scanner(new File("D:\\logs\\DOC_ID_"+i+".txt"));
        Doc document = new Doc("doc"+i);
        while(tdsc.hasNext()){
            String word = tdsc.next();
            document.put(word);
            Set<Doc> documents = wordDocMap.get(word);
            if(documents == null){
                documents = new HashSet<>();
                wordDocMap.put(word, documents);
            }
            documents.add(document);
        }
        tdsc.close();
    }

    StringBuilder builder = new StringBuilder();
    for(String word: wordDocMap.keySet()) {
        Set<Doc> documents = wordDocMap.get(word);
        builder.append(word + ":");
        for(Doc document:documents){
            builder.append(document.getDocName() +":"+ document.getCount(word));
            builder.append(", ");
        }
        builder.delete(builder.length()-2, builder.length()-1);
        builder.append("\n");
    }
    System.out.println(builder);
}

static class Doc {
    String docName;
    Map<String, Integer> m = new HashMap<>();

    public Doc(String docName){
        this.docName = docName;
    }

    public void put(String word) {
        Integer freq = m.get(word);
        m.put(word, (freq == null) ? 1 : freq + 1);
    }

    public Integer getCount(String word) {
        return m.get(word);
    }

    public String getDocName() {
        return this.docName;
    }
}
   
}  