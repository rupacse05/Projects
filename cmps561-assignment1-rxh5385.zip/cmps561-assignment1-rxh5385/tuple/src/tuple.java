
import java.beans.Statement;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer One
 */
public class tuple {
    public static void main(String[]args) throws FileNotFoundException, UnsupportedEncodingException, SQLException, ClassNotFoundException, Exception{
        File file2 = new File("D:\\logs\\tuple.txt");
        PrintWriter tupled = new PrintWriter(file2, "UTF-8");
        List<Map<String, Integer>> list = new ArrayList<>();
        Map<String, Integer>map= new HashMap<>();;
        String word;
    //Iterate over documents
    for (int i = 1; i <= 1400; i++) {
        //map = new HashMap<>();
        Scanner tdsc = new Scanner(new File("D:\\logs\\AfterStem" + i + ".txt"));
        //Iterate over words
        while (tdsc.hasNext()) {
            word = tdsc.next();
            final Integer freq = map.get(word);
            if (freq == null) {
                map.put(word, 1);
            } else {
                map.put(word, map.get(word) + 1);
            }
        }
        list.add(map);
    }
    // tupled.println(list);
     //tupled.close();
    //Print result
    int documentNumber = 0;
    for (Map<String, Integer> document : list) {
        for (Map.Entry<String, Integer> entry : document.entrySet()) {
            documentNumber++;
            //System.out.println(entry.getKey() + ":doc"+documentNumber+":" + entry.getValue());
            tupled.print(entry.getKey());
            tupled.print(":doc:");
            tupled.print(Integer.toString(documentNumber));
            tupled.print(",");
            tupled.println(entry.getValue());
            
            
        }
        //documentNumber++;
    }
    tupled.close();
    
   String dbURL2 = "jdbc:derby://localhost:1527/dem;create=true";
            String user = "nbuser";
            String password = "nbuser";
            Connection conn2 = DriverManager.getConnection(dbURL2, user, password);
            if (conn2 != null) {
                System.out.println("Connected to database #2");
            }
           java.sql.Statement st = conn2.createStatement(); 
           //st.executeUpdate("INSERT INTO FRIENDS " + "VALUES (1001, 'Simpson', '1002', 'JA')");
          // st.executeUpdate();*/
             
    
    }
    
}
    